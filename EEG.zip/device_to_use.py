import os
gpu_list = [0]
origin_data_document = "D:\\eegdata"
project_root_path = os.getcwd()